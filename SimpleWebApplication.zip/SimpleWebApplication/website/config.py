SITE_KEY = '6LfUjDopAAAAAKz6sWU9DB6Ma_x_Y0gK_-HKpvEP'
SECRET_KEY = '6LfUjDopAAAAAGEPVV2FXFFbKPSNV-gf07sbHwvl'
VERIFY_URL = 'https://www.google.com/recaptcha/api/siteverify'
